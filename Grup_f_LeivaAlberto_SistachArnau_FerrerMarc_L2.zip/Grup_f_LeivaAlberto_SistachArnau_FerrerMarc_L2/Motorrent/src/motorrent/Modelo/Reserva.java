/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package motorrent.Modelo;

/**
 *
 * @author Marc
 */
public class Reserva {
    private int Codi;
    private int Retard;
    private Data DataR;
    private Data DataD;
    private Data DataRe;
    private Local Origen;
    private Local Desti;
    private Moto m;
}
