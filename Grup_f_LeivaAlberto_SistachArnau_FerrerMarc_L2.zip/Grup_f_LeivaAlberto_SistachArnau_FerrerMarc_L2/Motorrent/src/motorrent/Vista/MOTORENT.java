/*
 * Nomes fa que cridar el visor
 */
package motorrent.Vista;

/**
 *
 * @author  Albert, Arnau i Marc
 */
public class MOTORENT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        Vista visor = new Vista ();
        visor.MenuNoIdentificado ();
    }
    
}
